﻿The font file in this archive was created using Fontstruct the free, online
font-building tool.
This font was created by Aaron Amar.
This font has a homepage where this archive and other versions may be found:
https://fontstruct.com/fontstructions/show/679568

Try Fontstruct at http://fontstruct.com
It’s easy and it’s fun.

NOTE FOR FLASH USERS: Fontstruct fonts (fontstructions) are optimized for Flash.
If the font in this archive is a pixel font, it is best displayed at a font-size
of 32.

Fontstruct is sponsored by FontShop.
Visit them at https://fontshop.com
FontShop is the original independent font retailer. We’ve been around since
the dawn of digital type. Whether you need the right font or need to create the
right font from scratch, let our 26 years of experience work for you.

Fontstruct is copyright ©2012-2017 Rob Meek

LEGAL NOTICE:
In using this font you must comply with the licensing terms described in the
file “license.txt” included with this archive.
If you redistribute the font file in this archive, it must be accompanied by all
the other files from this archive, including this one.
